# Platformă Educațională — Next.js + Firebase + SCORM

## Funcționalități
- Editor lecții cu salvare în Firebase
- Export SCORM pentru Moodle
- Template-uri educaționale OER reutilizabile

## Deploy rapid pe Vercel
1. Descarcă arhiva și extrage local
2. Creează cont pe https://vercel.com
3. Adaugă variabilele din `.env.local` în interfața Vercel
4. Click „Deploy”
5. Adaugă subdomeniul: editor.step-romania.ro
