import LessonEditor from "../components/LessonEditor"
export default function Home() {
  return <LessonEditor />
}
