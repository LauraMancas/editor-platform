import LessonEditor from "./LessonEditor"
export default function Home() {
  return <LessonEditor />
}
