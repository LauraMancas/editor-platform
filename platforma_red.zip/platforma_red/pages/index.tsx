import LessonEditor from "LessonEditor.tsx"
export default function Home() {
  return <LessonEditor />
}
