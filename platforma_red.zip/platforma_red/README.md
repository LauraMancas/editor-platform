# Platformă Educațională — Next.js + Firebase + SCORM

## Funcționalități
- Editor lecții cu salvare în Firebase
- Export SCORM pentru Moodle
- Template-uri educaționale OER reutilizabile

## Deploy rapid pe Vercel
1. Clonează repo-ul
2. Creează cont pe https://vercel.com
3. Adaugă variabilele .env.local
4. Click “Deploy” 🚀
